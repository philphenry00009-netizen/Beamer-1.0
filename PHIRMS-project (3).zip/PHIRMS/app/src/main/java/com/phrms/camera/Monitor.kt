package com.phrms.camera

import android.content.Context
import android.graphics.*
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

/** Sizes itself to the largest rectangle of the given aspect that fits its parent. */
class AspectFrame(c: Context) : FrameLayout(c) {
    private var aw = 16
    private var ah = 9
    fun setAspect(w: Int, h: Int) { if (w != aw || h != ah) { aw = w; ah = h; requestLayout() } }
    override fun onMeasure(ws: Int, hs: Int) {
        val mw = MeasureSpec.getSize(ws)
        val mh = MeasureSpec.getSize(hs)
        var w = mw
        var h = w * ah / aw
        if (h > mh) { h = mh; w = h * aw / ah }
        super.onMeasure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }
}

/** Draws corner brackets, grid, histogram, waveform, zebra/peaking layer, audio meter, focus box + exposure sun. */
class OverlayView(c: Context) : View(c) {
    var showHist = false
    var showWave = false
    var showAudio = false
    var layerOn = false
    var grid = 1
    @Volatile var audio = 0f
    var hist = IntArray(64)
    var wave = IntArray(64 * 64)
    var layer: Bitmap? = null
    var tapX = -1f
    var tapY = -1f
    var tapAt = 0L
    var evFrac = 0.5f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = Rect()
    private val d = c.resources.displayMetrics.density
    private val yel = 0xFFFFD60A.toInt()

    private fun corner(cv: Canvas, x: Float, y: Float, sx: Float, sy: Float) {
        val l = 18 * d
        cv.drawLine(x, y, x + sx * l, y, p); cv.drawLine(x, y, x, y + sy * l, p)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (layerOn) layer?.let { dst.set(0, 0, width, height); cv.drawBitmap(it, null, dst, null) }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = 0x88FFFFFF.toInt()
        if (grid >= 1) for (i in 1..2) {
            cv.drawLine(w * i / 3, 0f, w * i / 3, h, p)
            cv.drawLine(0f, h * i / 3, w, h * i / 3, p)
        }
        if (grid >= 2) {
            cv.drawLine(w / 2 - 14 * d, h / 2, w / 2 + 14 * d, h / 2, p)
            cv.drawLine(w / 2, h / 2 - 14 * d, w / 2, h / 2 + 14 * d, p)
            cv.drawRect(w * 0.05f, h * 0.05f, w * 0.95f, h * 0.95f, p)
            cv.drawRect(w * 0.10f, h * 0.10f, w * 0.90f, h * 0.90f, p)
        }
        p.strokeWidth = 2f * d
        p.color = 0xCCFFFFFF.toInt()
        corner(cv, 0f, 0f, 1f, 1f); corner(cv, w, 0f, -1f, 1f); corner(cv, 0f, h, 1f, -1f); corner(cv, w, h, -1f, -1f)

        p.style = Paint.Style.FILL
        val x0 = 24 * d
        val bw = 150 * d
        val bh = 60 * d
        var y0 = 64 * d
        if (showHist) {
            p.color = 0x66000000
            cv.drawRect(x0, y0, x0 + bw, y0 + bh, p)
            val mx = (hist.maxOrNull() ?: 1) + 1
            p.color = 0xCCFFFFFF.toInt()
            for (i in 0 until 64) {
                val hh = bh * hist[i] / mx
                cv.drawRect(x0 + i * bw / 64, y0 + bh - hh, x0 + (i + 1) * bw / 64, y0 + bh, p)
            }
            y0 += bh + 6 * d
        }
        if (showWave) {
            p.color = 0x66000000
            cv.drawRect(x0, y0, x0 + bw, y0 + bh, p)
            for (col in 0 until 64) for (bin in 0 until 64) {
                val n = wave[col * 64 + bin]
                if (n > 0) {
                    p.color = Color.argb(min(255, n * 10), 80, 255, 120)
                    cv.drawRect(x0 + col * bw / 64, y0 + bh - (bin + 1) * bh / 64, x0 + (col + 1) * bw / 64, y0 + bh - bin * bh / 64, p)
                }
            }
        }
        if (showAudio) {
            val db = 20f * log10(max(audio, 1e-5f))
            val f = ((db + 60f) / 60f).coerceIn(0f, 1f)
            val top = 70 * d
            val bot = h - 90 * d
            p.color = 0x66000000
            cv.drawRect(6 * d, top, 12 * d, bot, p)
            p.color = if (f > 0.9f) Color.RED else if (f > 0.75f) Color.YELLOW else Color.GREEN
            cv.drawRect(6 * d, bot - (bot - top) * f, 12 * d, bot, p)
        }
        if (System.currentTimeMillis() - tapAt < 3500 && tapX >= 0) {
            val cx = tapX * w
            val cy = tapY * h
            val half = 36 * d
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * d
            p.color = yel
            cv.drawRect(cx - half, cy - half, cx + half, cy + half, p)
            val t = 6 * d
            cv.drawLine(cx - half, cy, cx - half + t, cy, p); cv.drawLine(cx + half, cy, cx + half - t, cy, p)
            cv.drawLine(cx, cy - half, cx, cy - half + t, p); cv.drawLine(cx, cy + half, cx, cy + half - t, p)
            val lx = min(cx + half + 16 * d, w - 16 * d)
            val len = 70 * d
            p.strokeWidth = 1.5f * d
            cv.drawLine(lx, cy - len, lx, cy + len, p)
            val sy = cy + len - evFrac.coerceIn(0f, 1f) * 2 * len
            p.style = Paint.Style.FILL
            cv.drawCircle(lx, sy, 4 * d, p)
            p.style = Paint.Style.STROKE
            for (i in 0 until 8) {
                val a = Math.toRadians(i * 45.0)
                cv.drawLine(lx + (7 * d * kotlin.math.cos(a)).toFloat(), sy + (7 * d * kotlin.math.sin(a)).toFloat(),
                    lx + (11 * d * kotlin.math.cos(a)).toFloat(), sy + (11 * d * kotlin.math.sin(a)).toFloat(), p)
            }
        }
    }
}

/** One shared analysis pass (luma) feeding histogram, waveform, zebra and focus peaking. */
class Analyzer(private val tv: TextureView, private val overlay: OverlayView) {
    companion object { const val W = 320; const val H = 180 }
    var zebra = false
    var peak = false
    private val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    private val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    private val px = IntArray(W * H)
    private val luma = IntArray(W * H)
    private val outPx = IntArray(W * H)
    private val busy = AtomicBoolean(false)
    private val exec = Executors.newSingleThreadExecutor()

    init { overlay.layer = out }

    fun tick() {
        overlay.layerOn = zebra || peak
        if (!(zebra || peak || overlay.showHist || overlay.showWave) || !tv.isAvailable) return
        if (!busy.compareAndSet(false, true)) return
        try { tv.getBitmap(bmp) } catch (e: Exception) { busy.set(false); return }
        exec.execute {
            try { process() } finally { busy.set(false) }
            overlay.postInvalidate()
        }
    }

    private fun process() {
        bmp.getPixels(px, 0, W, 0, 0, W, H)
        val hist = overlay.hist
        val wave = overlay.wave
        hist.fill(0); wave.fill(0)
        for (i in px.indices) {
            val c = px[i]
            val l = (((c shr 16) and 255) * 54 + ((c shr 8) and 255) * 183 + (c and 255) * 19) shr 8
            luma[i] = l
            hist[l shr 2]++
            wave[((i % W) / 5) * 64 + (l shr 2)]++
        }
        if (zebra || peak) {
            for (y in 0 until H) for (x in 0 until W) {
                val i = y * W + x
                var o = 0
                if (zebra && luma[i] >= 240 && ((x + y) / 4) % 2 == 0) o = 0xCCFF3030.toInt()
                else if (peak && x < W - 1 && y < H - 1 &&
                    abs(luma[i] - luma[i + 1]) + abs(luma[i] - luma[i + W]) > 48) o = 0xFF00FF66.toInt()
                outPx[i] = o
            }
            out.setPixels(outPx, 0, W, 0, 0, W, H)
        }
    }
}

/** Input level meter (AudioRecord). Stopped while MediaRecorder owns the microphone. */
class AudioMeter(private val onLevel: (Float) -> Unit) {
    @Volatile private var run = false
    private var thread: Thread? = null

    fun start() {
        if (run) return
        run = true
        thread = Thread {
            val rate = 48000
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) { run = false; return@Thread }
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
            } catch (e: Exception) { run = false; return@Thread }
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); run = false; return@Thread }
            val buf = ShortArray(2400)
            try {
                rec.startRecording()
                while (run) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) break
                    var pk = 0
                    for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > pk) pk = a }
                    onLevel(pk / 32768f)
                }
            } catch (e: Exception) {
            } finally {
                try { rec.stop() } catch (e: Exception) {}
                rec.release()
                run = false
            }
        }.also { it.start() }
    }

    fun stop() {
        run = false
        try { thread?.join(800) } catch (e: Exception) {}
        thread = null
    }
}
