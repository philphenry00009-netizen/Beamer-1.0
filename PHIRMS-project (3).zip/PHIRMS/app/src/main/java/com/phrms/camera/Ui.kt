package com.phrms.camera

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Shutter button: white ring + white disc (photo), red disc (video), red rounded square (recording). */
class ShutterView(c: Context) : View(c) {
    var video = false
        set(v) { field = v; invalidate() }
    var rec = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = c.resources.displayMetrics.density
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 3 * d
        p.style = Paint.Style.STROKE; p.strokeWidth = 4 * d; p.color = Color.WHITE
        cv.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.FILL
        p.color = if (video) 0xFFFF3B30.toInt() else Color.WHITE
        if (rec) {
            val s = r * 0.45f
            cv.drawRoundRect(cx - s, cy - s, cx + s, cy + s, 8 * d, 8 * d, p)
        } else cv.drawCircle(cx, cy, r - 7 * d, p)
    }
}

/** Simple drawn icons so no image assets are needed. kind: 0 = gear, 1 = flip camera, 2 = sun/brightness. */
class IconView(c: Context, private val kind: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = c.resources.displayMetrics.density
    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.2f * d
        when (kind) {
            0 -> {
                cv.drawCircle(cx, cy, s * 0.26f, p)
                cv.drawCircle(cx, cy, s * 0.10f, p)
                p.strokeWidth = 3.2f * d
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    cv.drawLine(cx + (s * 0.26f * cos(a)).toFloat(), cy + (s * 0.26f * sin(a)).toFloat(),
                        cx + (s * 0.38f * cos(a)).toFloat(), cy + (s * 0.38f * sin(a)).toFloat(), p)
                }
            }
            2 -> {
                cv.drawCircle(cx, cy, s * 0.14f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    cv.drawLine(cx + (s * 0.22f * cos(a)).toFloat(), cy + (s * 0.22f * sin(a)).toFloat(),
                        cx + (s * 0.34f * cos(a)).toFloat(), cy + (s * 0.34f * sin(a)).toFloat(), p)
                }
            }
            else -> {
                val r = s * 0.24f
                val box = RectF(cx - r, cy - r, cx + r, cy + r)
                cv.drawArc(box, 200f, 140f, false, p)
                cv.drawArc(box, 20f, 140f, false, p)
                p.style = Paint.Style.FILL
                for (deg in floatArrayOf(340f, 160f)) {
                    val a = Math.toRadians(deg.toDouble())
                    val px = cx + (r * cos(a)).toFloat()
                    val py = cy + (r * sin(a)).toFloat()
                    val tx = (-sin(a)).toFloat()
                    val ty = cos(a).toFloat()
                    val nx = cos(a).toFloat()
                    val ny = sin(a).toFloat()
                    val path = Path()
                    path.moveTo(px + tx * 6 * d, py + ty * 6 * d)
                    path.lineTo(px + nx * 4.5f * d, py + ny * 4.5f * d)
                    path.lineTo(px - nx * 4.5f * d, py - ny * 4.5f * d)
                    path.close()
                    cv.drawPath(path, p)
                }
            }
        }
    }
}
