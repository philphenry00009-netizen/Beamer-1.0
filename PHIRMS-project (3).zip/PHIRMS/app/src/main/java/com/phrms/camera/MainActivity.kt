package com.phrms.camera

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.*
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.TonemapCurve
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.MediaActionSound
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.util.Range
import android.util.Size
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

class MainActivity : Activity() {
    private val tag = "PHIRMS"
    private val yel = 0xFFFFD60A.toInt()
    private val modes = listOf("CINEMATIC", "VIDEO", "PHOTO", "PORTRAIT", "PRO")
    private class Lens(val id: String, val factor: Float)
    private class LensBtn(val label: String, val id: String, val zoom: Float, val factor: Float)

    private lateinit var cm: CameraManager
    private lateinit var frame: AspectFrame
    private lateinit var tv: TextureView
    private lateinit var overlay: OverlayView
    private lateinit var analyzer: Analyzer
    private lateinit var status: TextView
    private lateinit var shutter: ShutterView
    private lateinit var thumb: ImageView
    private lateinit var chipLook: TextView; private lateinit var chipRes: TextView; private lateinit var chipFps: TextView
    private lateinit var evRow: LinearLayout; private lateinit var evBar: SeekBar; private lateinit var tEv: TextView
    private lateinit var depthRow: LinearLayout; private lateinit var depthBar: SeekBar; private lateinit var depthLabel: TextView
    private lateinit var lensRow: LinearLayout
    private lateinit var strip: LinearLayout; private lateinit var stripHost: FrameLayout
    private lateinit var panel: LinearLayout
    private lateinit var bExp: Button; private lateinit var bFocus: Button
    private lateinit var sIso: SeekBar; private lateinit var sShut: SeekBar; private lateinit var sFocus: SeekBar
    private lateinit var tIso: TextView; private lateinit var tShut: TextView; private lateinit var tFocus: TextView
    private val modeTvs = mutableListOf<TextView>()

    private val audioMeter = AudioMeter { overlay.audio = it }
    private val sound by lazy { MediaActionSound() }
    private val prefs by lazy { getSharedPreferences("phirms", MODE_PRIVATE) }
    private val ui = Handler(Looper.getMainLooper())
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null
    private val openLock = Semaphore(1)
    private val lockHeld = AtomicBoolean(false)

    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var chars: CameraCharacteristics? = null
    private var builder: CaptureRequest.Builder? = null
    private var jpegReader: ImageReader? = null
    private var camId: String? = null

    // settings
    private var modeIdx = 2
    private var facing = CameraCharacteristics.LENS_FACING_BACK
    private var lensId: String? = null
    private var fps = 30
    private var prevFps = 30
    private var cineFps = false
    private var resH = 1080
    private var hevc = false
    private var mbps = 20
    private var wbIdx = 0
    private var stabIdx = 0
    private var manualExp = false
    private var manualFocus = false
    private var iso = 100
    private var expNs = 16_666_666L
    private var focusP = 0f
    private var evIdx = 0
    private var zoom = 1f
    private var lookIdx = 0
    private var jpegQ = 95
    private var soundOn = true
    private var timerSec = 0
    private var infoOn = false
    private var depthP = 0.6f
    private var regions: Array<MeteringRectangle>? = null

    // capabilities of the open camera
    private var lenses = listOf<Lens>()
    private var lensBtns = listOf<LensBtn>()
    private var videoSizes = listOf<Size>()
    private var videoSize = Size(1920, 1080)
    private var previewSize = Size(1920, 1080)
    private var photoSize = Size(1920, 1080)
    private var fpsList = listOf(30)
    private var manualOk = false
    private var isoRange = Range(100, 100)
    private var expRange = Range(1_000_000L, 1_000_000L)
    private var minFocus = 0f
    private var evRange = Range(0, 0)
    private var evStep = 0f
    private var zoomMin = 1f
    private var zoomMax = 1f
    private var useRatio = false
    private var maxAf = 0
    private var maxAe = 0
    private var wbModes = listOf(CameraMetadata.CONTROL_AWB_MODE_AUTO to "AWB")
    private var stabOpts = listOf("OFF")
    private var looks = listOf("OFF")
    private val hevcOk by lazy { encoderExists("video/hevc") }

    // recording / state
    @Volatile private var recording = false
    @Volatile private var pendingPortrait = false
    private var recorder: MediaRecorder? = null
    private var recUri: Uri? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recStart = 0L
    private var lastUri: Uri? = null
    private var lastMime = "image/jpeg"
    @Volatile private var tel = ""
    private var lastTel = 0L
    private var tickN = 0
    private var scaled = false

    private val frameNs get() = (1e9 / fps).toLong()
    private fun isPhoto() = modes[modeIdx] == "PHOTO" || modes[modeIdx] == "PORTRAIT"
    private fun hasPerm(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cam(block: () -> Unit) {
        bg?.post { try { block() } catch (e: Exception) { Log.e(tag, "camera op failed", e); toast("Error: ${e.message}") } }
    }
    @Suppress("DEPRECATION")
    private fun rotation() = windowManager.defaultDisplay.rotation
    private fun isLand() = rotation().let { it == Surface.ROTATION_90 || it == Surface.ROTATION_270 }

    // ───────────────────────── lifecycle ─────────────────────────
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        loadPrefs()
        buildUi()
        if (!hasPerm(Manifest.permission.CAMERA) || !hasPerm(Manifest.permission.RECORD_AUDIO))
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onResume() {
        super.onResume()
        bgThread = HandlerThread("phirms-cam").also { it.start() }
        bg = Handler(bgThread!!.looper)
        if (hasPerm(Manifest.permission.CAMERA) && tv.isAvailable) cam { openCamera() }
        if (hasPerm(Manifest.permission.RECORD_AUDIO) && !isPhoto()) audioMeter.start()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, null)
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        savePrefs()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        audioMeter.stop()
        bg?.post { try { stopRecording(false); closeCamera() } catch (e: Exception) { Log.e(tag, "pause", e) } }
        bgThread?.quitSafely()
        try { bgThread?.join(4000) } catch (e: Exception) {}
        bgThread = null; bg = null
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) { runOnUiThread { applyTransform() } }
    }

    private val ticker = object : Runnable {
        override fun run() {
            tickN++
            if (recording) overlay.audio = try { (recorder?.maxAmplitude ?: 0) / 32768f } catch (e: Exception) { 0f }
            if (tickN % 2 == 0) analyzer.tick()
            if (tickN % 10 == 0) checkLimits()
            if (tickN % 3 == 0 && countdown == 0) {
                val t = if (recording) (SystemClock.elapsedRealtime() - recStart) / 1000 else -1
                val rec = if (t >= 0) String.format(Locale.US, "● %02d:%02d:%02d  ", t / 3600, t / 60 % 60, t % 60) else ""
                val show = recording || modes[modeIdx] == "PRO" || infoOn
                status.visibility = if (show) View.VISIBLE else View.GONE
                status.setTextColor(if (recording) 0xFFFF453A.toInt() else Color.WHITE)
                status.text = rec + (if (modes[modeIdx] == "PRO" || infoOn) tel else "")
            }
            overlay.invalidate()
            ui.postDelayed(this, 100)
        }
    }

    private fun checkLimits() {
        val free = freeBytes()
        val thermal = (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus
        if (recording && free < 150L * 1024 * 1024) { toast("Storage almost full – stopping"); cam { stopRecording() } }
        if (recording && thermal >= PowerManager.THERMAL_STATUS_CRITICAL) { toast("Device too hot – stopping"); cam { stopRecording() } }
        else if (thermal >= PowerManager.THERMAL_STATUS_SEVERE && tickN % 100 == 0) toast("Device is very warm")
    }

    @Suppress("DEPRECATION")
    private fun freeBytes() = StatFs(Environment.getExternalStorageDirectory().path).availableBytes

    // ───────────────────────── prefs ─────────────────────────
    private fun loadPrefs() = prefs.run {
        modeIdx = getInt("mode", 2).coerceIn(0, 4)
        fps = getInt("fps", 30); resH = getInt("resH", 1080); hevc = getBoolean("hevc", false); mbps = getInt("mbps", 20)
        wbIdx = getInt("wb", 0); stabIdx = getInt("stab", 0); manualExp = getBoolean("mexp", false); manualFocus = getBoolean("mf", false)
        facing = getInt("facing", CameraCharacteristics.LENS_FACING_BACK); lensId = getString("lensId", null)
        lookIdx = getInt("look", 0); jpegQ = getInt("jq", 95); soundOn = getBoolean("snd", true); timerSec = getInt("timer", 0)
        infoOn = getBoolean("info", false); depthP = getFloat("depth", 0.6f)
    }

    private fun savePrefs() = prefs.edit().apply {
        putInt("mode", modeIdx); putInt("fps", if (cineFps) prevFps else fps); putInt("resH", resH); putBoolean("hevc", hevc); putInt("mbps", mbps)
        putInt("wb", wbIdx); putInt("stab", stabIdx); putBoolean("mexp", manualExp); putBoolean("mf", manualFocus)
        putInt("facing", facing); putString("lensId", lensId); putInt("look", lookIdx); putInt("jq", jpegQ)
        putBoolean("snd", soundOn); putInt("timer", timerSec); putBoolean("info", infoOn); putFloat("depth", depthP)
        putBoolean("hist", overlay.showHist); putBoolean("wave", overlay.showWave); putBoolean("zebra", analyzer.zebra)
        putBoolean("peak", analyzer.peak); putInt("grid", overlay.grid)
    }.apply()

    // ───────────────────────── UI ─────────────────────────
    private fun fl(w: Int, h: Int, g: Int = Gravity.NO_GRAVITY) = FrameLayout.LayoutParams(w, h, g)

    private fun chip(onClick: () -> Unit) = TextView(this).apply {
        textSize = 12f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(8), dp(6), dp(8), dp(6)); setOnClickListener { onClick() }
    }

    private fun btn(parent: LinearLayout, onClick: () -> Unit): Button {
        val b = Button(this).apply {
            setAllCaps(false); textSize = 11f; minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setPadding(dp(10), dp(6), dp(10), dp(6)); setBackgroundColor(Color.TRANSPARENT); setTextColor(Color.WHITE)
            setOnClickListener { onClick() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-2, dp(34)))
        return b
    }

    private fun slider(parent: LinearLayout, onP: (Double) -> Unit): Pair<SeekBar, TextView> {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val t = TextView(this).apply { setTextColor(Color.WHITE); textSize = 10f; typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER }
        val s = SeekBar(this).apply { max = 1000 }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                onP(p / 1000.0); refresh(); labels()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        box.addView(t); box.addView(s)
        parent.addView(box, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        return s to t
    }

    private fun buildUi() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        frame = AspectFrame(this); tv = TextureView(this); overlay = OverlayView(this)
        frame.addView(tv, fl(-1, -1)); frame.addView(overlay, fl(-1, -1))
        analyzer = Analyzer(tv, overlay)
        overlay.showHist = prefs.getBoolean("hist", false); overlay.showWave = prefs.getBoolean("wave", false)
        analyzer.zebra = prefs.getBoolean("zebra", false); analyzer.peak = prefs.getBoolean("peak", false)
        overlay.grid = prefs.getInt("grid", 1)
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                applyTransform(); if (hasPerm(Manifest.permission.CAMERA)) cam { openCamera() }
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { applyTransform() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        setupTouch()

        // top bar
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(4)) }
        top.addView(IconView(this, 0).apply { setOnClickListener { showSettings() } }, LinearLayout.LayoutParams(dp(40), dp(40)))
        top.addView(IconView(this, 2).apply {
            setOnClickListener { evRow.visibility = if (evRow.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(8) })
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        chipLook = chip { cycleLook() }; chipRes = chip { cycleRes() }; chipFps = chip { cycleFps() }
        top.addView(chipLook); top.addView(chipRes); top.addView(chipFps)

        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.MONOSPACE; setPadding(dp(16), 0, dp(16), dp(2)); visibility = View.GONE
        }
        // brightness (exposure compensation) bar
        evRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, dp(16), 0); visibility = View.GONE }
        tEv = TextView(this).apply { setTextColor(yel); textSize = 12f; typeface = Typeface.MONOSPACE; minWidth = dp(64) }
        evBar = SeekBar(this).apply { max = 1000 }
        evBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                evIdx = (evRange.lower + (evRange.upper - evRange.lower) * p / 1000.0).roundToInt(); refresh(); labels()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        evRow.addView(tEv); evRow.addView(evBar, LinearLayout.LayoutParams(0, -2, 1f))

        // manual panel (PRO mode)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xCC000000.toInt()); setPadding(dp(8), dp(4), dp(8), dp(4)); visibility = View.GONE
        }
        val prow = LinearLayout(this)
        bExp = btn(prow) {
            if (!manualOk) toast("Manual exposure not supported by this camera") else { manualExp = !manualExp; refresh(); labels(); syncSliders() }
        }
        bFocus = btn(prow) {
            if (minFocus <= 0f) toast("Manual focus not supported by this camera") else { manualFocus = !manualFocus; refresh(); labels() }
        }
        panel.addView(prow)
        val srow = LinearLayout(this)
        val a = slider(srow) { p ->
            iso = exp(ln(isoRange.lower.toDouble()) + (ln(isoRange.upper.toDouble()) - ln(isoRange.lower.toDouble())) * p).roundToInt().coerceIn(isoRange.lower, isoRange.upper)
        }; sIso = a.first; tIso = a.second
        val b2 = slider(srow) { p ->
            expNs = exp(ln(shutMin().toDouble()) + (ln(shutMax().toDouble()) - ln(shutMin().toDouble())) * p).toLong()
        }; sShut = b2.first; tShut = b2.second
        val c = slider(srow) { p -> focusP = p.toFloat() }; sFocus = c.first; tFocus = c.second
        panel.addView(srow)

        // portrait depth control
        depthRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(24), dp(2), dp(24), dp(2)); visibility = View.GONE; setBackgroundColor(0x66000000) }
        depthLabel = TextView(this).apply { setTextColor(yel); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; minWidth = dp(84) }
        depthBar = SeekBar(this).apply { max = 1000; progress = (depthP * 1000).toInt() }
        depthBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { depthP = p / 1000f; labels() }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        depthRow.addView(depthLabel); depthRow.addView(depthBar, LinearLayout.LayoutParams(0, -2, 1f))

        lensRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(6)) }
        val floatCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        floatCol.addView(panel, LinearLayout.LayoutParams(-1, -2)); floatCol.addView(depthRow, LinearLayout.LayoutParams(-1, -2))
        floatCol.addView(lensRow, LinearLayout.LayoutParams(-2, -2))

        // mode carousel
        strip = LinearLayout(this)
        stripHost = FrameLayout(this)
        val swipe = object : View.OnTouchListener {
            var x0 = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.actionMasked == MotionEvent.ACTION_DOWN) x0 = e.rawX
                if (e.actionMasked == MotionEvent.ACTION_UP && abs(e.rawX - x0) > dp(40)) { setMode(modeIdx + if (e.rawX < x0) 1 else -1); return true }
                return false
            }
        }
        for (i in modes.indices) {
            val t = TextView(this).apply { text = modes[i]; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { setMode(i) } }
            t.setOnTouchListener(swipe)
            modeTvs.add(t); strip.addView(t)
        }
        stripHost.addView(strip, fl(-2, -1, Gravity.START))
        stripHost.setOnTouchListener(swipe)

        // capture controls
        thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF1C1C1E.toInt()); clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(10).toFloat()) }
            }
            setOnClickListener { openLast() }
        }
        shutter = ShutterView(this).apply { setOnClickListener { onShutter() } }
        val flip = IconView(this, 1).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x66333333) }
            setOnClickListener { cam { switchCamera() } }
        }

        if (!land) {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
            col.addView(top); col.addView(status); col.addView(evRow)
            val mid = FrameLayout(this)
            mid.addView(frame, fl(-1, -1, Gravity.CENTER))
            mid.addView(floatCol, fl(-1, -2, Gravity.BOTTOM))
            col.addView(mid, LinearLayout.LayoutParams(-1, 0, 1f))
            col.addView(stripHost, LinearLayout.LayoutParams(-1, dp(40)))
            val ctl = FrameLayout(this)
            ctl.addView(thumb, fl(dp(52), dp(52), Gravity.CENTER_VERTICAL or Gravity.START).apply { leftMargin = dp(32) })
            ctl.addView(shutter, fl(dp(76), dp(76), Gravity.CENTER))
            ctl.addView(flip, fl(dp(52), dp(52), Gravity.CENTER_VERTICAL or Gravity.END).apply { rightMargin = dp(32) })
            col.addView(ctl, LinearLayout.LayoutParams(-1, dp(104)))
            setContentView(col)
        } else {
            val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
            root.addView(frame, fl(-1, -1, Gravity.CENTER))
            val tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            tcol.addView(top); tcol.addView(status); tcol.addView(evRow)
            root.addView(tcol, fl(-1, -2, Gravity.TOP))
            val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            right.addView(thumb, LinearLayout.LayoutParams(dp(52), dp(52)).apply { bottomMargin = dp(14) })
            right.addView(shutter, LinearLayout.LayoutParams(dp(76), dp(76)))
            right.addView(flip, LinearLayout.LayoutParams(dp(52), dp(52)).apply { topMargin = dp(14) })
            root.addView(right, fl(dp(110), -1, Gravity.END))
            val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            bottom.addView(floatCol, LinearLayout.LayoutParams(-1, -2))
            bottom.addView(stripHost, LinearLayout.LayoutParams(dp(340), dp(40)))
            root.addView(bottom, fl(-1, -2, Gravity.BOTTOM).apply { rightMargin = dp(110) })
            setContentView(root)
        }
        applyModeUi()
        labels()
    }

    private fun setupTouch() {
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoom = (zoom * d.scaleFactor).coerceIn(zoomMin, zoomMax); scaled = true; refresh(); refreshLensRow(); return true
            }
        })
        var dx0 = 0f; var dy0 = 0f; var ev0 = 0; var dragEv = false
        frame.setOnTouchListener { v, e ->
            sd.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { scaled = false; dragEv = false; dx0 = e.x; dy0 = e.y; ev0 = evIdx }
                MotionEvent.ACTION_MOVE -> if (!scaled && e.pointerCount == 1 && !manualExp &&
                    System.currentTimeMillis() - overlay.tapAt < 4000 && abs(e.y - dy0) > abs(e.x - dx0) && abs(e.y - dy0) > dp(10)) {
                    dragEv = true
                    val n = evIdx
                    evIdx = (ev0 + ((dy0 - e.y) / dp(22)).toInt()).coerceIn(evRange.lower, evRange.upper)
                    overlay.tapAt = System.currentTimeMillis()
                    if (evIdx != n) { refresh(); labels() }
                }
                MotionEvent.ACTION_UP -> if (!scaled && !dragEv && e.pointerCount == 1) {
                    val dx = e.x - dx0; val dy = e.y - dy0
                    if (abs(dx) > dp(80) && abs(dx) > 2 * abs(dy)) setMode(modeIdx + if (dx < 0) 1 else -1)
                    else if (abs(dx) < dp(12) && abs(dy) < dp(12)) tapFocus(e.x / v.width, e.y / v.height)
                }
            }
            true
        }
    }

    private fun shutMin() = max(expRange.lower, 125_000L)
    private fun shutMax() = max(shutMin() + 1, min(frameNs, expRange.upper))

    private fun curFactor() = lenses.firstOrNull { it.id == camId }?.factor ?: 1f

    private fun fmtZoom(z: Float) = if (abs(z - z.roundToInt()) < 0.05f) "${z.roundToInt()}" else String.format(Locale.US, "%.1f", z)

    private fun refreshLensRow() {
        val eff = curFactor() * zoom
        var best = -1; var bd = Float.MAX_VALUE
        lensBtns.forEachIndexed { i, b -> val dd = abs(ln(eff / b.factor)); if (dd < bd) { bd = dd; best = i } }
        for (i in 0 until lensRow.childCount) {
            val t = lensRow.getChildAt(i) as TextView
            val sel = i == best
            t.text = if (sel) fmtZoom(eff) + "×" else lensBtns[i].label
            t.setTextColor(if (sel) yel else Color.WHITE)
            t.textSize = if (sel) 14f else 12f
        }
    }

    private fun rebuildLensRow() {
        lensRow.removeAllViews()
        lensBtns.forEach { b ->
            val t = TextView(this).apply {
                gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99000000.toInt()) }
                setOnClickListener { pickLens(b) }
            }
            lensRow.addView(t, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(5); marginEnd = dp(5) })
        }
        refreshLensRow()
    }

    private fun labels() {
        chipLook.text = "LOOK " + looks[lookIdx.coerceIn(0, looks.size - 1)]
        chipLook.setTextColor(if (lookIdx != 0) yel else Color.WHITE)
        chipRes.text = if (resH >= 2160) "4K" else "${resH}p"; chipFps.text = "$fps"
        bExp.text = if (manualExp) "EXP:MAN" else "EXP:AUTO"; bFocus.text = if (manualFocus) "MF" else "AF"
        bExp.setTextColor(if (manualExp) 0xFF66FF99.toInt() else Color.WHITE); bFocus.setTextColor(if (manualFocus) 0xFF66FF99.toInt() else Color.WHITE)
        tIso.text = "ISO " + (if (manualExp) "$iso" else "AUTO")
        val e = expNs.coerceIn(shutMin(), shutMax())
        tShut.text = if (manualExp) "1/${(1e9 / e).roundToInt()}  ${(e * 360.0 / frameNs).roundToInt()}°" else "SHUTTER AUTO"
        tFocus.text = if (manualFocus) "FOCUS " + (if (focusP <= 0.01f) "INF" else String.format(Locale.US, "%.2fm", 1f / (focusP * minFocus))) else "FOCUS AUTO"
        tEv.text = if (manualExp) "EV –" else String.format(Locale.US, "%+.1f EV", evIdx * evStep)
        sIso.isEnabled = manualExp; sShut.isEnabled = manualExp; sFocus.isEnabled = manualFocus; evBar.isEnabled = !manualExp
        val f = 16.0 * (1.4 / 16.0).pow(depthP.toDouble())
        depthLabel.text = String.format(Locale.US, "ƒ %.1f", f)
        overlay.evFrac = if (evRange.upper > evRange.lower) (evIdx - evRange.lower).toFloat() / (evRange.upper - evRange.lower) else 0.5f
        refreshLensRow()
    }

    private fun syncSliders() {
        fun lp(v: Double, a: Double, b: Double) = if (b > a) ((ln(v) - ln(a)) / (ln(b) - ln(a)) * 1000).toInt().coerceIn(0, 1000) else 0
        sIso.progress = lp(iso.toDouble(), isoRange.lower.toDouble(), isoRange.upper.toDouble())
        sShut.progress = lp(expNs.toDouble().coerceIn(shutMin().toDouble(), shutMax().toDouble()), shutMin().toDouble(), shutMax().toDouble())
        sFocus.progress = (focusP * 1000).toInt()
        evBar.progress = if (evRange.upper > evRange.lower) ((evIdx - evRange.lower) * 1000 / (evRange.upper - evRange.lower)) else 500
        labels()
    }

    private fun applyModeUi() {
        val m = modes[modeIdx]
        for (i in modeTvs.indices) modeTvs[i].setTextColor(if (i == modeIdx) yel else Color.WHITE)
        panel.visibility = if (m == "PRO") View.VISIBLE else View.GONE
        depthRow.visibility = if (m == "PORTRAIT") View.VISIBLE else View.GONE
        chipRes.visibility = if (isPhoto()) View.GONE else View.VISIBLE
        chipFps.visibility = if (isPhoto()) View.GONE else View.VISIBLE
        shutter.video = !isPhoto()
        overlay.showAudio = !isPhoto()
        stripHost.post {
            val t = modeTvs[modeIdx]
            strip.animate().translationX(stripHost.width / 2f - (t.left + t.width / 2f)).setDuration(160).start()
        }
    }

    private fun setMode(i: Int) {
        if (recording || i < 0 || i >= modes.size || i == modeIdx) return
        val oldPhoto = isPhoto()
        modeIdx = i
        if (modes[i] == "CINEMATIC") {
            if (!cineFps && 24 in fpsList) { prevFps = fps; fps = 24; cineFps = true }
        } else if (cineFps) { fps = prevFps; cineFps = false }
        applyModeUi(); labels()
        if (isPhoto()) audioMeter.stop() else if (hasPerm(Manifest.permission.RECORD_AUDIO)) audioMeter.start()
        if (oldPhoto != isPhoto()) cam { closeCamera(); openCamera() } else refresh()
    }

    private fun setRecUi(rec: Boolean) {
        shutter.rec = rec
        chipRes.isEnabled = !rec; chipFps.isEnabled = !rec
        requestedOrientation = if (rec) ActivityInfo.SCREEN_ORIENTATION_LOCKED else ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        if (rec) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun setFrameAspect() {
        if (isLand()) frame.setAspect(previewSize.width, previewSize.height) else frame.setAspect(previewSize.height, previewSize.width)
    }

    /** Same transform as Google's Camera2Basic sample: portrait needs none, landscape needs un-rotating. */
    private fun applyTransform() {
        setFrameAspect()
        val vw = tv.width.toFloat(); val vh = tv.height.toFloat()
        if (vw == 0f || vh == 0f) return
        val cx = vw / 2f; val cy = vh / 2f
        val m = Matrix()
        val rot = rotation()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            val buf = RectF(0f, 0f, previewSize.height.toFloat(), previewSize.width.toFloat())
            buf.offset(cx - buf.centerX(), cy - buf.centerY())
            m.setRectToRect(RectF(0f, 0f, vw, vh), buf, Matrix.ScaleToFit.FILL)
            val s = max(vh / previewSize.height, vw / previewSize.width)
            m.postScale(s, s, cx, cy)
            m.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) m.postRotate(180f, cx, cy)
        tv.setTransform(m)
    }

    private fun cycleLook() { lookIdx = (lookIdx + 1) % looks.size; refresh(); labels() }

    private fun openLast() {
        val u = lastUri
        if (u == null) { toast("Nothing captured yet"); return }
        try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, lastMime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        catch (e: Exception) { toast("No app found to open it") }
    }

    private fun setThumb(uri: Uri) = Thread {
        try {
            val bmp = contentResolver.loadThumbnail(uri, Size(192, 192), null)
            runOnUiThread { thumb.setImageBitmap(bmp) }
        } catch (e: Exception) { Log.w(tag, "thumb", e) }
    }.start()

    private fun showSettings() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        fun row(label: String, value: () -> String, tap: () -> Unit) {
            val b = Button(this)
            fun upd() { b.text = "$label:  ${value()}" }
            b.setOnClickListener { tap(); upd(); labels() }
            upd(); col.addView(b, LinearLayout.LayoutParams(-1, -2))
        }
        row("Resolution", { if (resH >= 2160) "4K (2160p)" else "${resH}p" }) { cycleRes() }
        row("Frame rate", { "$fps fps" }) { cycleFps() }
        row("Codec", { if (hevc) "HEVC (H.265)" else "AVC (H.264)" }) { if (hevcOk) { hevc = !hevc } else { toast("No HEVC encoder on this device") } }
        row("Bitrate", { "$mbps Mbps" }) { mbps = when (mbps) { 10 -> 20; 20 -> 40; 40 -> 80; else -> 10 } }
        row("White balance", { wbModes[wbIdx.coerceIn(0, wbModes.size - 1)].second }) { wbIdx = (wbIdx + 1) % wbModes.size; refresh() }
        row("Stabilization", { stabOpts[stabIdx.coerceIn(0, stabOpts.size - 1)] }) { stabIdx = (stabIdx + 1) % stabOpts.size; refresh() }
        row("Look / filter", { looks[lookIdx.coerceIn(0, looks.size - 1)] }) { cycleLook() }
        row("Photo quality", { "JPEG $jpegQ" }) { jpegQ = when (jpegQ) { 80 -> 90; 90 -> 95; else -> 80 } }
        row("Self-timer", { if (timerSec == 0) "OFF" else "${timerSec}s" }) { timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 } }
        row("Camera sounds", { if (soundOn) "ON" else "OFF" }) { soundOn = !soundOn }
        row("Grid", { listOf("OFF", "THIRDS", "GUIDES")[overlay.grid] }) { overlay.grid = (overlay.grid + 1) % 3 }
        row("Camera info line", { if (infoOn) "ON" else "OFF" }) { infoOn = !infoOn }
        row("Histogram", { if (overlay.showHist) "ON" else "OFF" }) { overlay.showHist = !overlay.showHist }
        row("Waveform", { if (overlay.showWave) "ON" else "OFF" }) { overlay.showWave = !overlay.showWave }
        row("Zebra", { if (analyzer.zebra) "ON" else "OFF" }) { analyzer.zebra = !analyzer.zebra }
        row("Focus peaking", { if (analyzer.peak) "ON" else "OFF" }) { analyzer.peak = !analyzer.peak }
        col.addView(Button(this).apply { text = "Phone camera list (lenses)"; setOnClickListener { showCamInfo() } }, LinearLayout.LayoutParams(-1, -2))
        col.addView(TextView(this).apply {
            text = "Videos: Movies/PHIRMS\nPhotos: Pictures/PHIRMS\nUnsupported looks are not listed."; setPadding(dp(8), dp(12), dp(8), dp(4))
        })
        AlertDialog.Builder(this).setTitle("PHIRMS settings")
            .setView(ScrollView(this).apply { addView(col) }).setPositiveButton("Close", null).show()
    }

    private fun focalEq(c: CameraCharacteristics): Float? {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return null
        val sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        return (f * 43.27 / hypot(sz.width.toDouble(), sz.height.toDouble())).toFloat()
    }

    private fun showCamInfo() {
        val sb = StringBuilder()
        try {
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                val face = when (c.get(CameraCharacteristics.LENS_FACING)) { CameraCharacteristics.LENS_FACING_FRONT -> "front"; CameraCharacteristics.LENS_FACING_BACK -> "back"; else -> "ext" }
                val eq = focalEq(c)?.roundToInt()?.toString() ?: "?"
                val lvl = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                    CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"; CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                    CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"; CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"; else -> "?" }
                val zr = if (Build.VERSION.SDK_INT >= 30) c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.toString() ?: "-" else "n/a"
                sb.append("ID $id  $face  ~${eq}mm  $lvl\n   physical=${c.physicalCameraIds}  zoom=$zr\n")
            }
        } catch (e: Exception) { sb.append("Error: ${e.message}") }
        sb.append("\nIf only one rear camera is listed, this phone hides its other lenses from third-party apps.")
        AlertDialog.Builder(this).setTitle("Phone cameras").setMessage(sb.toString()).setPositiveButton("Close", null).show()
    }

    // ───────────────────────── camera ─────────────────────────
    private val stateCb = object : CameraDevice.StateCallback() {
        override fun onOpened(c: CameraDevice) { unlock(); camera = c; cam { startPreview() } }
        override fun onDisconnected(c: CameraDevice) { unlock(); c.close(); camera = null }
        override fun onError(c: CameraDevice, e: Int) {
            unlock(); c.close(); camera = null; toast("Camera error $e")
            if (recording) cam { stopRecording(false) }
        }
    }

    private fun unlock() { if (lockHeld.getAndSet(false)) openLock.release() }

    private fun lensIds(): List<String> = cm.cameraIdList.filter {
        val c = cm.getCameraCharacteristics(it)
        c.get(CameraCharacteristics.LENS_FACING) == facing &&
            (c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE) ?: true)
    }

    private fun discoverLenses(ids: List<String>) {
        val eqs = ids.map { it to (focalEq(cm.getCameraCharacteristics(it)) ?: 26f) }
        val main = eqs.minByOrNull { abs(it.second - 26f) }?.second ?: 26f
        lenses = eqs.map { Lens(it.first, it.second / main) }.sortedBy { it.factor }
    }

    private fun zoomRatioLower(id: String): Float =
        if (Build.VERSION.SDK_INT >= 30) cm.getCameraCharacteristics(id).get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.lower ?: 1f else 1f

    private fun buildLensBtns() {
        val l = mutableListOf<LensBtn>()
        for (ln in lenses) {
            val f = ln.factor
            l += LensBtn(if (f < 0.75f) "0.5" else if (f < 1.4f) "1" else "${f.roundToInt()}", ln.id, 1f, f)
        }
        if (facing == CameraCharacteristics.LENS_FACING_BACK) {
            val mainId = lenses.minByOrNull { abs(it.factor - 1f) }?.id
            if (mainId != null) {
                if (l.none { it.factor < 0.75f } && zoomRatioLower(mainId) <= 0.55f) l += LensBtn("0.5", mainId, 0.5f, 0.5f)
                if (l.none { it.factor >= 1.8f }) l += LensBtn("2", mainId, 2f, 2f)
            }
        }
        lensBtns = l.sortedBy { it.factor }
        runOnUiThread { rebuildLensRow() }
    }

    private fun pickLens(b: LensBtn) {
        if (b.id == camId) { zoom = b.zoom.coerceIn(zoomMin, zoomMax); refresh(); refreshLensRow(); return }
        if (recording) { toast("Stop recording to change lens"); return }
        lensId = b.id; zoom = b.zoom
        cam { closeCamera(); openCamera() }
    }

    @Suppress("MissingPermission")
    private fun openCamera() {
        if (camera != null || !hasPerm(Manifest.permission.CAMERA) || !tv.isAvailable) return
        if (!openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) { toast("Camera busy"); return }
        lockHeld.set(true)
        try {
            val ids = lensIds()
            if (ids.isEmpty()) { unlock(); toast("No camera found"); return }
            discoverLenses(ids)
            val id = if (lensId != null && lensId in ids) lensId!! else (lenses.minByOrNull { abs(it.factor - 1f) }?.id ?: ids[0])
            lensId = id; camId = id
            chars = cm.getCameraCharacteristics(id)
            configure()
            buildLensBtns()
            runOnUiThread { applyTransform(); syncSliders(); applyModeUi() }
            cm.openCamera(id, stateCb, bg)
        } catch (e: Exception) { unlock(); Log.e(tag, "open", e); toast("Open failed: ${e.message}") }
    }

    private fun closeCamera() {
        val got = openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)
        if (got) lockHeld.set(true)
        try {
            session?.close(); session = null
            camera?.close(); camera = null
            jpegReader?.close(); jpegReader = null
            builder = null
        } finally { unlock() }
    }

    private fun switchCamera() {
        if (recording) return
        facing = if (facing == CameraCharacteristics.LENS_FACING_BACK) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
        lensId = null; regions = null; zoom = 1f
        closeCamera(); openCamera()
    }

    private fun cycleRes() {
        if (videoSizes.isEmpty() || recording) return
        val i = (videoSizes.indexOf(videoSize) + 1) % videoSizes.size
        resH = videoSizes[i].height
        cam { closeCamera(); openCamera() }
    }

    private fun cycleFps() {
        if (recording) return
        fps = fpsList[(fpsList.indexOf(fps) + 1) % fpsList.size]
        if (cineFps && fps != 24) cineFps = false
        expNs = expNs.coerceIn(shutMin(), shutMax())
        refresh(); labels(); syncSliders()
    }

    private fun encoderExists(mime: String) = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        .any { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }

    private fun clampBitrate(bps: Int, mime: String): Int = try {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .firstOrNull { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }
            ?.getCapabilitiesForType(mime)?.videoCapabilities?.bitrateRange?.clamp(bps) ?: bps
    } catch (e: Exception) { bps }

    /** Reads real hardware capabilities; nothing is assumed. */
    private fun configure() {
        val ch = chars!!
        val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val all = (map.getOutputSizes(MediaRecorder::class.java) ?: emptyArray()).toList()
        var v = all.filter { it.width * 9 == it.height * 16 && it.height in 720..2160 }.sortedBy { it.height }
        if (v.isEmpty()) v = all.filter { it.height in 480..2160 }.sortedBy { it.width * it.height }
        if (v.isEmpty()) v = listOf(all.maxByOrNull { it.width * it.height } ?: Size(1280, 720))
        videoSizes = v
        videoSize = v.firstOrNull { it.height == resH } ?: v.minByOrNull { abs(it.height - resH) }!!
        resH = videoSize.height
        val prev = (map.getOutputSizes(SurfaceTexture::class.java) ?: emptyArray()).filter { it.width <= 1920 }
        val jp = (map.getOutputSizes(ImageFormat.JPEG) ?: emptyArray()).toList()
        val aw = if (isPhoto()) 4 else videoSize.width
        val ah = if (isPhoto()) 3 else videoSize.height
        fun same(s: Size) = s.width * ah == s.height * aw
        previewSize = prev.filter { same(it) }.maxByOrNull { it.width * it.height } ?: prev.maxByOrNull { it.width * it.height } ?: Size(1280, 720)
        photoSize = jp.filter { same(it) }.maxByOrNull { it.width * it.height } ?: jp.maxByOrNull { it.width * it.height } ?: previewSize

        val ranges = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
        val minDur = map.getOutputMinFrameDuration(MediaRecorder::class.java, videoSize)
        fpsList = listOf(24, 25, 30, 60).filter { f ->
            (ranges?.any { it.lower <= f && it.upper >= f } ?: (f <= 30)) && (minDur <= 0 || 1e9 / minDur >= f - 0.5)
        }.ifEmpty { listOf(30) }
        if (fps !in fpsList) fps = if (30 in fpsList) 30 else fpsList.last()
        if (modes[modeIdx] == "CINEMATIC" && !cineFps && 24 in fpsList) { prevFps = fps; fps = 24; cineFps = true }

        manualOk = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) == true
        isoRange = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 100)
        expRange = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 1_000_000L)
        minFocus = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        evRange = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        evStep = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
        val zr = if (Build.VERSION.SDK_INT >= 30) ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) else null
        useRatio = zr != null
        zoomMin = zr?.lower ?: 1f
        zoomMax = min(10f, zr?.upper ?: (ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f))
        maxAf = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0
        maxAe = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0
        if (!manualOk) manualExp = false
        if (minFocus <= 0f) manualFocus = false
        iso = iso.coerceIn(isoRange.lower, isoRange.upper)
        expNs = expNs.coerceIn(shutMin(), shutMax())
        evIdx = evIdx.coerceIn(evRange.lower, evRange.upper)
        zoom = zoom.coerceIn(zoomMin, zoomMax)

        val awb = ch.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.toList() ?: emptyList()
        wbModes = listOf(
            CameraMetadata.CONTROL_AWB_MODE_AUTO to "AWB", CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT to "DAYLIGHT",
            CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT to "CLOUDY", CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT to "TUNGSTEN",
            CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT to "FLUORESCENT"
        ).filter { it.first in awb }.ifEmpty { listOf(CameraMetadata.CONTROL_AWB_MODE_AUTO to "AWB") }
        wbIdx = wbIdx.coerceIn(0, wbModes.size - 1)
        val st = mutableListOf("OFF")
        if (ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true) st += "OIS"
        if (ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true) st += "EIS"
        stabOpts = st; stabIdx = stabIdx.coerceIn(0, st.size - 1)

        val l = mutableListOf("OFF")
        val tm = ch.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)?.toList() ?: emptyList()
        if (CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE in tm && (ch.get(CameraCharacteristics.TONEMAP_MAX_CURVE_POINTS) ?: 0) >= 5)
            l += listOf("CONTRAST", "TEAL-ORANGE", "WARM", "COOL", "FADED")
        val fx = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_EFFECTS)?.toList() ?: emptyList()
        if (CameraMetadata.CONTROL_EFFECT_MODE_MONO in fx) l += "B&W"
        if (CameraMetadata.CONTROL_EFFECT_MODE_SEPIA in fx) l += "SEPIA"
        if (CameraMetadata.CONTROL_EFFECT_MODE_NEGATIVE in fx) l += "NEGATIVE"
        if (CameraMetadata.CONTROL_EFFECT_MODE_AQUA in fx) l += "AQUA"
        if (CameraMetadata.CONTROL_EFFECT_MODE_POSTERIZE in fx) l += "POSTERIZE"
        looks = l; lookIdx = lookIdx.coerceIn(0, l.size - 1)
        if (hevc && !hevcOk) hevc = false
    }

    /** Screen rotation relative to sensor; also used for JPEG and video orientation. */
    private fun rel(): Int {
        val sens = chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val disp = when (rotation()) { Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0 }
        return if (facing == CameraCharacteristics.LENS_FACING_FRONT) (sens + disp) % 360 else (sens - disp + 360) % 360
    }

    private fun cropRect(): Rect {
        val a = chars!!.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!
        val z = max(zoom, 1f)
        val w = (a.width() / z).toInt(); val h = (a.height() / z).toInt()
        return Rect(a.centerX() - w / 2, a.centerY() - h / 2, a.centerX() + w / 2, a.centerY() + h / 2)
    }

    private fun lookCurve(n: String): TonemapCurve? {
        fun c(r: FloatArray, g: FloatArray = r, b: FloatArray = r) = TonemapCurve(r, g, b)
        return when (n) {
            "CONTRAST" -> c(floatArrayOf(0f, 0f, 0.25f, 0.18f, 0.5f, 0.5f, 0.75f, 0.82f, 1f, 1f))
            "TEAL-ORANGE" -> c(
                floatArrayOf(0f, 0f, 0.25f, 0.20f, 0.5f, 0.52f, 0.75f, 0.85f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.25f, 0.5f, 0.50f, 0.75f, 0.74f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.31f, 0.5f, 0.48f, 0.75f, 0.68f, 1f, 1f))
            "WARM" -> c(
                floatArrayOf(0f, 0f, 0.25f, 0.28f, 0.5f, 0.55f, 0.75f, 0.80f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.25f, 0.5f, 0.50f, 0.75f, 0.75f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.22f, 0.5f, 0.45f, 0.75f, 0.70f, 1f, 1f))
            "COOL" -> c(
                floatArrayOf(0f, 0f, 0.25f, 0.22f, 0.5f, 0.45f, 0.75f, 0.70f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.25f, 0.5f, 0.50f, 0.75f, 0.75f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.28f, 0.5f, 0.55f, 0.75f, 0.80f, 1f, 1f))
            "FADED" -> c(floatArrayOf(0f, 0.08f, 0.25f, 0.28f, 0.5f, 0.52f, 0.75f, 0.76f, 1f, 0.95f))
            else -> null
        }
    }

    private fun applyControls(b: CaptureRequest.Builder, record: Boolean) {
        val ch = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        if (useRatio && Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom.coerceIn(zoomMin, zoomMax))
        else b.set(CaptureRequest.SCALER_CROP_REGION, cropRect())
        val fr = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.filter { it.lower <= fps && it.upper >= fps }
            ?.minByOrNull { it.upper - it.lower }
        if (manualExp) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs.coerceIn(shutMin(), shutMax()))
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, frameNs)
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIdx)
            if (fr != null && !isPhoto()) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fr)
        }
        if (manualFocus && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusP * minFocus)
        } else b.set(CaptureRequest.CONTROL_AF_MODE, if (record) CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO else CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        b.set(CaptureRequest.CONTROL_AWB_MODE, wbModes[wbIdx.coerceIn(0, wbModes.size - 1)].first)
        val stab = stabOpts[stabIdx.coerceIn(0, stabOpts.size - 1)]
        if ("OIS" in stabOpts) b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, if (stab == "OIS") 1 else 0)
        if ("EIS" in stabOpts) b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, if (stab == "EIS" && record) 1 else 0)
        val look = looks[lookIdx.coerceIn(0, looks.size - 1)]
        b.set(CaptureRequest.CONTROL_EFFECT_MODE, when (look) {
            "B&W" -> CameraMetadata.CONTROL_EFFECT_MODE_MONO; "SEPIA" -> CameraMetadata.CONTROL_EFFECT_MODE_SEPIA
            "NEGATIVE" -> CameraMetadata.CONTROL_EFFECT_MODE_NEGATIVE; "AQUA" -> CameraMetadata.CONTROL_EFFECT_MODE_AQUA
            "POSTERIZE" -> CameraMetadata.CONTROL_EFFECT_MODE_POSTERIZE; else -> CameraMetadata.CONTROL_EFFECT_MODE_OFF
        })
        lookCurve(look)?.let { b.set(CaptureRequest.TONEMAP_MODE, CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE); b.set(CaptureRequest.TONEMAP_CURVE, it) }
        regions?.let {
            if (maxAf > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, it)
            if (maxAe > 0 && !manualExp) b.set(CaptureRequest.CONTROL_AE_REGIONS, it)
        }
    }

    private fun refresh() = cam {
        val b = builder ?: return@cam
        val s = session ?: return@cam
        applyControls(b, recording)
        s.setRepeatingRequest(b.build(), captureCb, bg)
    }

    private val captureCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastTel < 250) return
            lastTel = now
            val i = res.get(CaptureResult.SENSOR_SENSITIVITY)
            val e = res.get(CaptureResult.SENSOR_EXPOSURE_TIME)
            val fd = res.get(CaptureResult.LENS_FOCUS_DISTANCE)
            val af = when (res.get(CaptureResult.CONTROL_AF_STATE)) {
                CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED, CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED -> "AF:OK"
                CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED -> "AF:FAIL"
                CaptureResult.CONTROL_AF_STATE_ACTIVE_SCAN, CaptureResult.CONTROL_AF_STATE_PASSIVE_SCAN -> "AF:SCAN"
                else -> ""
            }
            tel = "ISO ${i ?: "-"}  1/${e?.let { (1e9 / it).roundToInt() } ?: "-"}  FOCUS " +
                (fd?.let { if (it < 0.05f) "INF" else String.format(Locale.US, "%.2fm", 1f / it) } ?: "-") + " $af  " +
                (if (isPhoto()) "${photoSize.width}x${photoSize.height}" else "${videoSize.width}x${videoSize.height} ${fps}p ${if (hevc) "HEVC" else "AVC"} ${mbps}M")
        }
    }

    @Suppress("DEPRECATION")
    private fun startPreview() {
        val c = camera ?: return
        val st = tv.surfaceTexture ?: return
        session?.close(); session = null
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        val ps = Surface(st)
        jpegReader?.close(); jpegReader = null
        val surfaces = mutableListOf(ps)
        if (isPhoto()) {
            val jr = ImageReader.newInstance(photoSize.width, photoSize.height, ImageFormat.JPEG, 2)
            jr.setOnImageAvailableListener({ savePhoto(it) }, bg)
            jpegReader = jr
            surfaces.add(jr.surface)
        }
        c.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                if (camera == null) return
                session = s
                val b = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                b.addTarget(ps); builder = b
                applyControls(b, false)
                try { s.setRepeatingRequest(b.build(), captureCb, bg) } catch (e: Exception) { Log.e(tag, "preview", e) }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) { toast("Preview configuration failed") }
        }, bg)
    }

    private fun tapFocus(nx0: Float, ny0: Float) {
        overlay.tapX = nx0; overlay.tapY = ny0; overlay.tapAt = System.currentTimeMillis()
        cam {
            val ch = chars ?: return@cam
            val crop = cropRect()
            val (nx, ny) = when (rel()) {
                90 -> ny0 to (1 - nx0)
                180 -> (1 - nx0) to (1 - ny0)
                270 -> (1 - ny0) to nx0
                else -> nx0 to ny0
            }
            val half = (min(crop.width(), crop.height()) * 0.07f).toInt()
            val cx = crop.left + (nx * crop.width()).toInt(); val cy = crop.top + (ny * crop.height()).toInt()
            val a = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!
            val x = (cx - half).coerceIn(a.left, a.right - 2 * half - 1); val y = (cy - half).coerceIn(a.top, a.bottom - 2 * half - 1)
            regions = arrayOf(MeteringRectangle(x, y, 2 * half, 2 * half, 1000))
            val b = builder ?: return@cam
            val s = session ?: return@cam
            applyControls(b, recording)
            if (!manualFocus && maxAf > 0) {
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL); s.capture(b.build(), null, bg)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START); s.capture(b.build(), null, bg)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
            }
            s.setRepeatingRequest(b.build(), captureCb, bg)
        }
    }

    // ───────────────────────── capture ─────────────────────────
    private var countdown = 0

    private fun onShutter() {
        if (!isPhoto()) { if (soundOn) sound.play(if (recording) MediaActionSound.STOP_VIDEO_RECORDING else MediaActionSound.START_VIDEO_RECORDING); toggleRecord(); return }
        if (timerSec > 0 && countdown == 0) { tickDown(timerSec) } else takePhoto()
    }

    private fun tickDown(n: Int) {
        if (n <= 0) { countdown = 0; status.visibility = View.GONE; takePhoto(); return }
        countdown = n; status.visibility = View.VISIBLE; status.setTextColor(yel); status.text = "   $n"
        ui.postDelayed({ tickDown(n - 1) }, 1000)
    }

    private fun takePhoto() = cam {
        if (recording || !isPhoto()) return@cam
        val c = camera ?: return@cam
        val jr = jpegReader ?: return@cam
        val s = session ?: return@cam
        pendingPortrait = modes[modeIdx] == "PORTRAIT"
        val b = c.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        b.addTarget(jr.surface)
        applyControls(b, false)
        b.set(CaptureRequest.JPEG_ORIENTATION, rel())
        b.set(CaptureRequest.JPEG_QUALITY, jpegQ.toByte())
        if (soundOn) sound.play(MediaActionSound.SHUTTER_CLICK)
        s.capture(b.build(), null, bg)
    }

    private fun savePhoto(r: ImageReader) {
        val img = r.acquireNextImage() ?: return
        val portrait = pendingPortrait
        val bytes = try {
            val buf = img.planes[0].buffer
            val arr = ByteArray(buf.remaining()); buf.get(arr); arr
        } finally { img.close() }
        if (portrait) {
            toast("Applying depth blur…")
            Portrait.process(bytes, depthP) { out, person ->
                if (out == null) { toast("Blur failed – saved normal photo"); writeJpeg(bytes, "PHIRMS") }
                else { writeJpeg(out, "PHIRMS_PORTRAIT"); if (!person) toast("No person found – used centre focus") }
            }
        } else writeJpeg(bytes, "PHIRMS")
    }

    private fun writeJpeg(bytes: ByteArray, prefix: String) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "${prefix}_${stamp()}.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/PHIRMS")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            lastUri = uri; lastMime = "image/jpeg"; setThumb(uri)
            toast("Photo saved to Pictures/PHIRMS")
        } catch (e: Exception) { Log.e(tag, "photo", e); toast("Photo save failed: ${e.message}") }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun toggleRecord() = cam { if (recording) stopRecording() else startRecording() }

    @Suppress("DEPRECATION")
    private fun startRecording() {
        val c = camera ?: return
        if (recording || isPhoto()) return
        if (freeBytes() < 500L * 1024 * 1024) { toast("Need at least 500 MB free storage"); return }
        try {
            audioMeter.stop()
            val audio = hasPerm(Manifest.permission.RECORD_AUDIO)
            if (!audio) toast("No microphone permission – recording video only")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder = rec
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "PHIRMS_${stamp()}.mp4")
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/PHIRMS")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            recUri = uri
            recPfd = contentResolver.openFileDescriptor(uri, "w")
            if (audio) rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setOutputFile(recPfd!!.fileDescriptor)
            val mime = if (hevc) "video/hevc" else "video/avc"
            rec.setVideoEncodingBitRate(clampBitrate(mbps * 1_000_000, mime))
            rec.setVideoFrameRate(fps)
            rec.setVideoSize(videoSize.width, videoSize.height)
            rec.setVideoEncoder(if (hevc) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            if (audio) { rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); rec.setAudioEncodingBitRate(192_000); rec.setAudioSamplingRate(48_000) }
            rec.setOrientationHint(rel())
            rec.setOnErrorListener { _, _, _ -> cam { stopRecording() } }
            rec.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) cam { stopRecording() }
            }
            rec.prepare()

            val st = tv.surfaceTexture ?: throw IllegalStateException("no preview surface")
            st.setDefaultBufferSize(previewSize.width, previewSize.height)
            val ps = Surface(st)
            val rs = rec.surface
            val b = c.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
            b.addTarget(ps); b.addTarget(rs)
            applyControls(b, true)
            session?.close(); session = null
            c.createCaptureSession(listOf(ps, rs), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    try {
                        session = s; builder = b
                        s.setRepeatingRequest(b.build(), captureCb, bg)
                        rec.start()
                        recStart = SystemClock.elapsedRealtime()
                        recording = true
                        runOnUiThread { setRecUi(true) }
                    } catch (e: Exception) { Log.e(tag, "rec start", e); toast("Recording failed: ${e.message}"); stopRecording() }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { toast("Recording not supported with these settings"); stopRecording() }
            }, bg)
        } catch (e: Exception) {
            Log.e(tag, "prepare", e); toast("Cannot start recording: ${e.message}"); stopRecording()
        }
    }

    private fun stopRecording(restart: Boolean = true) {
        if (!recording && recorder == null) return
        var ok = recording
        recording = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (e: Exception) {}
        recorder?.let { r ->
            try { r.stop() } catch (e: RuntimeException) { ok = false; Log.e(tag, "stop", e) }
            try { r.reset() } catch (e: Exception) {}
            r.release()
        }
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        recUri?.let { u ->
            if (ok) {
                contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                lastUri = u; lastMime = "video/mp4"; setThumb(u)
                toast("Video saved to Movies/PHIRMS")
            } else { contentResolver.delete(u, null, null) }
        }
        recUri = null
        runOnUiThread { setRecUi(false) }
        if (restart) {
            if (hasPerm(Manifest.permission.RECORD_AUDIO) && !isPhoto()) audioMeter.start()
            startPreview()
        }
    }
}
