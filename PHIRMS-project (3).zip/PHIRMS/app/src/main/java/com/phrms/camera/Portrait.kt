package com.phrms.camera

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.sqrt

/** Software portrait blur: person mask from ML Kit selfie segmentation, falls back to a centre-focus blur. */
object Portrait {
    private val exec = Executors.newSingleThreadExecutor()
    private val segmenter by lazy {
        Segmentation.getClient(
            SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).enableRawSizeMask().build()
        )
    }

    /** amount 0..1 (more = stronger blur). done(jpeg or null, usedPersonMask). Called on a background thread. */
    fun process(jpeg: ByteArray, amount: Float, done: (ByteArray?, Boolean) -> Unit) {
        exec.execute {
            try {
                val work = decodeUpright(jpeg)
                segmenter.process(InputImage.fromBitmap(work, 0))
                    .addOnSuccessListener { m -> exec.execute { finish(work, m.buffer, m.width, m.height, amount, done) } }
                    .addOnFailureListener { exec.execute { finish(work, null, 0, 0, amount, done) } }
            } catch (e: Throwable) { done(null, false) }
        }
    }

    private fun decodeUpright(jpeg: ByteArray): Bitmap {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, o)
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 2200) s *= 2
        var bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, BitmapFactory.Options().apply { inSampleSize = s })!!
        val deg = when (ExifInterface(ByteArrayInputStream(jpeg)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90; ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270; else -> 0
        }
        if (deg != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg.toFloat()) }, true)
        return bmp
    }

    private fun smooth(c: Float): Float { val t = ((c - 0.3f) / 0.4f).coerceIn(0f, 1f); return t * t * (3 - 2 * t) }

    private fun finish(src: Bitmap, buf: ByteBuffer?, mw: Int, mh: Int, amount: Float, done: (ByteArray?, Boolean) -> Unit) {
        try {
            val w = src.width
            val h = src.height
            val alpha = FloatArray(w * h)
            var used = false
            if (buf != null && mw == w && mh == h) {
                buf.rewind()
                var sum = 0.0
                for (i in 0 until w * h) { val a = smooth(buf.float); alpha[i] = a; sum += a }
                used = sum / (w * h) > 0.02
            }
            if (!used) {
                for (y in 0 until h) for (x in 0 until w) {
                    val dx = (x - w / 2f) / (w * 0.38f)
                    val dy = (y - h * 0.48f) / (h * 0.32f)
                    val t = ((sqrt(dx * dx + dy * dy) - 0.8f) / 0.5f).coerceIn(0f, 1f)
                    alpha[y * w + x] = 1f - t * t * (3 - 2 * t)
                }
            }
            blurFloat(alpha, w, h, max(2, w / 220))
            val sw = max(8, w / 6)
            val sh = max(8, h / 6)
            val small = Bitmap.createScaledBitmap(src, sw, sh, true)
            val sp = IntArray(sw * sh)
            small.getPixels(sp, 0, sw, 0, 0, sw, sh)
            blurInt(sp, sw, sh, 2 + (amount * 14).toInt())
            small.setPixels(sp, 0, sw, 0, 0, sw, sh)
            val big = Bitmap.createScaledBitmap(small, w, h, true)
            val ps = IntArray(w * h)
            val pb = IntArray(w * h)
            src.getPixels(ps, 0, w, 0, 0, w, h)
            big.getPixels(pb, 0, w, 0, 0, w, h)
            for (i in ps.indices) {
                val a = alpha[i]
                val s = ps[i]
                val b = pb[i]
                val r = (((s shr 16) and 255) * a + ((b shr 16) and 255) * (1 - a)).toInt()
                val g = (((s shr 8) and 255) * a + ((b shr 8) and 255) * (1 - a)).toInt()
                val bl = ((s and 255) * a + (b and 255) * (1 - a)).toInt()
                ps[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
            }
            val out = Bitmap.createBitmap(ps, w, h, Bitmap.Config.ARGB_8888)
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 95, bos)
            done(bos.toByteArray(), used)
        } catch (e: Throwable) { done(null, false) }
    }

    private fun blurInt(px: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(px.size)
        repeat(2) {
            for (y in 0 until h) lineInt(px, tmp, y * w, 1, w, r)
            for (x in 0 until w) lineInt(tmp, px, x, w, h, r)
        }
    }

    private fun lineInt(src: IntArray, dst: IntArray, start: Int, stride: Int, n: Int, r: Int) {
        var sr = 0; var sg = 0; var sb = 0
        val win = 2 * r + 1
        for (k in -r..r) { val c = src[start + k.coerceIn(0, n - 1) * stride]; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255 }
        for (i in 0 until n) {
            dst[start + i * stride] = (0xFF shl 24) or ((sr / win) shl 16) or ((sg / win) shl 8) or (sb / win)
            val add = src[start + (i + r + 1).coerceAtMost(n - 1) * stride]
            val rem = src[start + (i - r).coerceAtLeast(0) * stride]
            sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
            sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
            sb += (add and 255) - (rem and 255)
        }
    }

    private fun blurFloat(a: FloatArray, w: Int, h: Int, r: Int) {
        val tmp = FloatArray(a.size)
        for (y in 0 until h) lineF(a, tmp, y * w, 1, w, r)
        for (x in 0 until w) lineF(tmp, a, x, w, h, r)
    }

    private fun lineF(src: FloatArray, dst: FloatArray, start: Int, stride: Int, n: Int, r: Int) {
        var s = 0f
        val win = 2 * r + 1
        for (k in -r..r) s += src[start + k.coerceIn(0, n - 1) * stride]
        for (i in 0 until n) {
            dst[start + i * stride] = s / win
            s += src[start + (i + r + 1).coerceAtMost(n - 1) * stride] - src[start + (i - r).coerceAtLeast(0) * stride]
        }
    }
}
